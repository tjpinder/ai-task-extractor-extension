import{g as R,r as x,a as ye,c as X,j as t,s as fe,i as be,b as we,d as ke,e as je,R as ve}from"./global.js";const Ne={high:"High",medium:"Medium",low:"Low"},Z={high:"#ef4444",medium:"#f59e0b",low:"#22c55e"},D={action:"Action Item","follow-up":"Follow-up",decision:"Decision Needed",deadline:"Deadline",question:"Open Question",idea:"Idea/Suggestion",other:"Other"},ie={action:"✓","follow-up":"↩",decision:"?",deadline:"⏰",question:"❓",idea:"💡",other:"•"},Ee={general:"General",email:"Email",meeting:"Meeting Notes"},ee={general:"Works on any web page content",email:"Optimized for Gmail, Outlook, and email threads",meeting:"Smart detection for agendas, action items, and decisions"},Pe={daily:"Daily",weekly:"Weekly",biweekly:"Every 2 weeks",monthly:"Monthly",quarterly:"Quarterly",yearly:"Yearly"},Te={"15min":"15 minutes","30min":"30 minutes","1h":"1 hour","2h":"2 hours","4h":"Half day","1d":"1 day","2d":"2 days","1w":"1 week"},Ce=`{
  "tasks": [
    {
      "title": "Clear actionable task title",
      "description": "Optional additional details",
      "priority": "high|medium|low",
      "category": "action|follow-up|decision|deadline|question|idea|other",
      "assignee": "Person name or null",
      "dueDate": "YYYY-MM-DD or null",
      "context": "Brief context of where this was found",
      "confidence": 0.85,
      "subTasks": [
        {"title": "Sub-task 1"},
        {"title": "Sub-task 2"}
      ],
      "recurring": {
        "frequency": "daily|weekly|biweekly|monthly|quarterly|yearly",
        "description": "Every Monday at 9am"
      },
      "timeEstimate": "15min|30min|1h|2h|4h|1d|2d|1w"
    }
  ]
}`,q=`Confidence guidelines:
- 0.9-1.0: Explicit action item with clear ownership or deadline
- 0.7-0.89: Strong implication of task, mentioned directly
- 0.5-0.69: Implicit task, inferred from context
- 0.3-0.49: Possible task, somewhat ambiguous
- Below 0.3: Weak signal, might not be a real task`,B=`Time estimation guidelines:
- 15min: Quick task, simple response or check
- 30min: Short task, single-step action
- 1h: Medium task, requires some focus
- 2h: Substantial task, multiple steps
- 4h: Half-day effort, complex work
- 1d: Full day of work
- 2d: Two days of work
- 1w: Week-long project`;function Se(l,i){return`You are an expert at identifying actionable tasks from text content. Analyze the following content and extract all actionable tasks, to-dos, action items, follow-ups, decisions needed, and deadlines.

Page Title: "${i}"

Content:
"""
${l.slice(0,15e3)}
"""

For each task you identify, determine:
1. A clear, actionable title (start with a verb when possible)
2. Any additional context or description
3. Priority level (high, medium, or low)
4. Category: action (something to do), follow-up (needs follow-up with someone), decision (decision needed), deadline (has a specific date), question (open question to answer), idea (suggestion or idea), other
5. Assignee if mentioned (person's name or role)
6. Due date if mentioned (in YYYY-MM-DD format)
7. Context (the surrounding context where this task was found)
8. Confidence (0.0 to 1.0) - how confident you are this is a real actionable task
9. Sub-tasks - if a task has clear sub-items or steps, include them
10. Recurring pattern - if the task mentions recurring ("every week", "daily", "monthly")
11. Time estimate - estimate how long the task might take based on complexity

Look for:
- Explicit action items (e.g., "need to", "should", "will", "must", "action item:")
- Deadlines and dates
- Follow-up mentions
- Questions that need answers
- Decisions that need to be made
- Assignments to specific people
- Recurring patterns ("every Monday", "weekly", "each month")
- Nested items or numbered lists that could be sub-tasks

${q}

${B}

Respond in this exact JSON format:
${Ce}

Notes:
- subTasks, recurring, and timeEstimate are optional - only include if detected
- If no tasks are found, return: {"tasks": []}
- Return only valid JSON, no other text.`}function $e(l,i){return`You are an expert at extracting actionable tasks from emails. Analyze this email content and identify all action items, requests, follow-ups, and commitments.

Email Subject: "${i}"

Email Content:
"""
${l.slice(0,15e3)}
"""

EMAIL-SPECIFIC EXTRACTION RULES:
1. Identify the email SENDER as a potential assignee for responses
2. Look for requests directed at the reader ("Could you...", "Please...", "Can you...")
3. Detect commitments made by the sender ("I will...", "I'll send you...")
4. Find deadlines mentioned with dates or relative timing ("by Friday", "next week", "ASAP")
5. Identify questions that need answers
6. Look for CC'd people who might need follow-up
7. Detect meeting requests or scheduling needs
8. Find forwarded items that need action

For each task, determine:
1. A clear, actionable title (start with a verb)
2. Description with relevant email context
3. Priority: high (urgent/ASAP/today), medium (this week), low (when possible)
4. Category: action, follow-up, decision, deadline, question, idea, other
5. Assignee (sender for their commitments, "me" for requests to reader)
6. Due date in YYYY-MM-DD format
7. Context from the email
8. Confidence score (0-1)
9. Sub-tasks if the email lists multiple items
10. Recurring pattern if applicable ("weekly status update")
11. Time estimate based on complexity
12. Sender's name if identifiable

${q}

${B}

Respond in this JSON format:
{
  "tasks": [
    {
      "title": "Clear actionable task",
      "description": "Email context",
      "priority": "high|medium|low",
      "category": "action|follow-up|decision|deadline|question|idea|other",
      "assignee": "Person name or null",
      "dueDate": "YYYY-MM-DD or null",
      "context": "From email about...",
      "confidence": 0.85,
      "subTasks": [{"title": "Sub-task"}],
      "recurring": {"frequency": "weekly", "description": "Every Monday"},
      "timeEstimate": "30min",
      "sender": "John Smith"
    }
  ]
}

If no tasks found, return: {"tasks": []}
Return only valid JSON.`}function Ae(l,i){return`You are an expert at extracting action items from meeting notes. Analyze these meeting notes and identify all action items, decisions made, follow-ups needed, and open questions.

Meeting Title: "${i}"

Meeting Notes:
"""
${l.slice(0,15e3)}
"""

MEETING-SPECIFIC EXTRACTION RULES:
1. Look for explicit "Action Item:" or "AI:" markers
2. Identify "Decision:" markers and log the decision
3. Find "Follow-up:" items that need future action
4. Extract items assigned to specific attendees
5. Detect "Next steps" or "To-do" sections
6. Identify agenda items that weren't completed
7. Find questions marked as "Open question" or "TBD"
8. Look for recurring meeting actions ("update in next week's meeting")
9. Detect deadlines mentioned ("complete by end of sprint")
10. Identify blockers that need resolution

For each task, determine:
1. A clear, actionable title (start with a verb)
2. Description with meeting context
3. Priority based on discussion emphasis
4. Category: action, follow-up, decision, deadline, question, idea, other
5. Assignee (meeting attendee responsible)
6. Due date in YYYY-MM-DD format
7. Context from discussion
8. Confidence score (0-1)
9. Sub-tasks for multi-step items
10. Recurring pattern ("review in weekly standup")
11. Time estimate based on scope discussed
12. Attendees mentioned (list of names)

${q}

${B}

Respond in this JSON format:
{
  "tasks": [
    {
      "title": "Clear actionable task",
      "description": "Meeting context",
      "priority": "high|medium|low",
      "category": "action|follow-up|decision|deadline|question|idea|other",
      "assignee": "Person name or null",
      "dueDate": "YYYY-MM-DD or null",
      "context": "Discussed in meeting...",
      "confidence": 0.85,
      "subTasks": [{"title": "Sub-task"}],
      "recurring": {"frequency": "weekly", "description": "Review in standup"},
      "timeEstimate": "2h",
      "attendees": ["John", "Sarah", "Mike"]
    }
  ]
}

If no tasks found, return: {"tasks": []}
Return only valid JSON.`}function De(l,i,a="general"){switch(a){case"email":return $e(l,i);case"meeting":return Ae(l,i);default:return Se(l,i)}}async function Ie(l,i){const a=await fetch("https://api.openai.com/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${l}`},body:JSON.stringify({model:"gpt-4o-mini",messages:[{role:"user",content:i}],temperature:.3,max_tokens:4e3})});if(!a.ok){const n=await a.text();throw new Error(`OpenAI API error: ${n}`)}return(await a.json()).choices[0].message.content}async function Me(l,i){const a=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json","x-api-key":l,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},body:JSON.stringify({model:"claude-3-5-haiku-latest",max_tokens:4e3,messages:[{role:"user",content:i}]})});if(!a.ok){const n=await a.text();throw new Error(`Anthropic API error: ${n}`)}return(await a.json()).content[0].text}async function Le(l,i,a){return l==="openai"?Ie(i,a):Me(i,a)}function Oe(l){const i=l.match(/```(?:json)?\s*([\s\S]*?)```/);if(i)return i[1].trim();const a=l.match(/\{[\s\S]*\}/);return a?a[0]:l.trim()}const _e=["15min","30min","1h","2h","4h","1d","2d","1w"],Re=["daily","weekly","biweekly","monthly","quarterly","yearly"];async function qe(l,i,a,c="general"){const n=a.aiProvider==="openai"?a.openaiApiKey:a.anthropicApiKey;if(!n)throw new Error(`Please configure your ${a.aiProvider==="openai"?"OpenAI":"Anthropic"} API key in settings`);const m=De(l,i,c),e=await Le(a.aiProvider,n,m);try{const p=Oe(e);return JSON.parse(p).tasks.map(d=>{let j;d.subTasks&&Array.isArray(d.subTasks)&&d.subTasks.length>0&&(j=d.subTasks.map(C=>({id:R(),title:C.title,completed:!1})));let v;d.recurring&&d.recurring.frequency&&Re.includes(d.recurring.frequency)&&(v={frequency:d.recurring.frequency,description:d.recurring.description||`Repeats ${d.recurring.frequency}`,dayOfWeek:d.recurring.dayOfWeek,dayOfMonth:d.recurring.dayOfMonth});let g;return d.timeEstimate&&_e.includes(d.timeEstimate)&&(g=d.timeEstimate),{id:R(),title:d.title,description:d.description,priority:d.priority||"medium",category:d.category||"action",assignee:d.assignee||void 0,dueDate:d.dueDate||void 0,context:d.context,confidence:typeof d.confidence=="number"?d.confidence:.7,selected:!0,subTasks:j,recurring:v,timeEstimate:g,sender:d.sender||void 0,attendees:d.attendees&&d.attendees.length>0?d.attendees:void 0}})}catch{throw new Error("Failed to parse AI response. Please try again.")}}function Be(l){return l.filter(i=>i.selected).map(i=>{let a=`${ie[i.category]} ${i.title}`;return i.assignee&&(a+=` (@${i.assignee})`),i.dueDate&&(a+=` [Due: ${i.dueDate}]`),i.priority==="high"&&(a+=" ⚡"),a}).join(`
`)}function Ye(l,i){const a=l.filter(p=>p.selected);let c=`# Tasks from "${i}"

`;c+=`_Extracted ${a.length} task(s)_

`;const n=a.filter(p=>p.priority==="high"),m=a.filter(p=>p.priority==="medium"),e=a.filter(p=>p.priority==="low");return n.length>0&&(c+=`## 🔴 High Priority

`,n.forEach(p=>{c+=_(p)}),c+=`
`),m.length>0&&(c+=`## 🟡 Medium Priority

`,m.forEach(p=>{c+=_(p)}),c+=`
`),e.length>0&&(c+=`## 🟢 Low Priority

`,e.forEach(p=>{c+=_(p)})),c}function _(l){let i=`- [ ] **${l.title}**`;const a=[];return l.assignee&&a.push(`👤 ${l.assignee}`),l.dueDate&&a.push(`📅 ${l.dueDate}`),a.length>0&&(i+=` (${a.join(" | ")})`),i+=`
`,l.description&&(i+=`  - ${l.description}
`),i}async function Ue(l,i,a){if(!i.notionApiKey||!i.notionDatabaseId)throw new Error("Please configure Notion API key and Database ID in settings");const c=l.filter(n=>n.selected);for(const n of c){const m={Name:{title:[{text:{content:n.title}}]},Priority:{select:{name:Ne[n.priority]}},Category:{select:{name:D[n.category]}},Source:{rich_text:[{text:{content:a}}]}};n.assignee&&(m.Assignee={rich_text:[{text:{content:n.assignee}}]}),n.dueDate&&(m["Due Date"]={date:{start:n.dueDate}}),n.description&&(m.Description={rich_text:[{text:{content:n.description}}]}),await fetch("https://api.notion.com/v1/pages",{method:"POST",headers:{Authorization:`Bearer ${i.notionApiKey}`,"Content-Type":"application/json","Notion-Version":"2022-06-28"},body:JSON.stringify({parent:{database_id:i.notionDatabaseId},properties:m})})}}async function Fe(l,i){if(!i.todoistApiKey)throw new Error("Please configure Todoist API key in settings");const a=l.filter(n=>n.selected),c={high:4,medium:3,low:2};for(const n of a){const m={content:n.title,priority:c[n.priority]};i.todoistProjectId&&(m.project_id=i.todoistProjectId),n.dueDate&&(m.due_date=n.dueDate),n.description&&(m.description=n.description),await fetch("https://api.todoist.com/rest/v2/tasks",{method:"POST",headers:{Authorization:`Bearer ${i.todoistApiKey}`,"Content-Type":"application/json"},body:JSON.stringify(m)})}}async function Je(l,i){if(!i.clickupApiKey||!i.clickupListId)throw new Error("Please configure ClickUp API key and List ID in settings");const a=l.filter(n=>n.selected),c={high:1,medium:2,low:3};for(const n of a){const m={name:n.title,priority:c[n.priority]};n.description&&(m.description=n.description),n.dueDate&&(m.due_date=new Date(n.dueDate).getTime()),await fetch(`https://api.clickup.com/api/v2/list/${i.clickupListId}/task`,{method:"POST",headers:{Authorization:i.clickupApiKey,"Content-Type":"application/json"},body:JSON.stringify(m)})}}async function te(l){await navigator.clipboard.writeText(l)}function We(l,i){const a=l.filter(e=>e.selected),c=["Title","Description","Priority","Category","Assignee","Due Date","Confidence","Source"],n=e=>e?e.includes(",")||e.includes('"')||e.includes(`
`)?`"${e.replace(/"/g,'""')}"`:e:"",m=a.map(e=>[n(e.title),n(e.description),e.priority,D[e.category],n(e.assignee),e.dueDate||"",e.confidence?`${Math.round(e.confidence*100)}%`:"",n(i)].join(","));return[c.join(","),...m].join(`
`)}function ze(l,i){const a=l.filter(n=>n.selected),c={source:i,exportedAt:new Date().toISOString(),taskCount:a.length,tasks:a.map(n=>({title:n.title,description:n.description||null,priority:n.priority,category:n.category,categoryLabel:D[n.category],assignee:n.assignee||null,dueDate:n.dueDate||null,confidence:n.confidence||null}))};return JSON.stringify(c,null,2)}function re(l,i,a){const c=new Blob([l],{type:a}),n=URL.createObjectURL(c),m=document.createElement("a");m.href=n,m.download=i,document.body.appendChild(m),m.click(),document.body.removeChild(m),URL.revokeObjectURL(n)}async function Ke(l,i){if(!i.asanaApiKey||!i.asanaProjectId)throw new Error("Please configure Asana API key and Project ID in settings");const a=l.filter(c=>c.selected);for(const c of a){const n={data:{name:c.title,projects:[i.asanaProjectId],notes:c.description||""}};c.dueDate&&(n.data.due_on=c.dueDate);const m=await fetch("https://app.asana.com/api/1.0/tasks",{method:"POST",headers:{Authorization:`Bearer ${i.asanaApiKey}`,"Content-Type":"application/json"},body:JSON.stringify(n)});if(!m.ok){const e=await m.text();throw new Error(`Asana API error: ${e}`)}}}async function Ve(l,i){if(!i.linearApiKey||!i.linearTeamId)throw new Error("Please configure Linear API key and Team ID in settings");const a=l.filter(n=>n.selected),c={high:2,medium:3,low:4};for(const n of a){const m=`
      mutation CreateIssue($input: IssueCreateInput!) {
        issueCreate(input: $input) {
          success
          issue {
            id
            title
          }
        }
      }
    `,e={input:{teamId:i.linearTeamId,title:n.title,description:n.description||"",priority:c[n.priority],...n.dueDate&&{dueDate:n.dueDate}}},p=await fetch("https://api.linear.app/graphql",{method:"POST",headers:{Authorization:i.linearApiKey,"Content-Type":"application/json"},body:JSON.stringify({query:m,variables:e})});if(!p.ok){const d=await p.text();throw new Error(`Linear API error: ${d}`)}const k=await p.json();if(k.errors)throw new Error(`Linear API error: ${k.errors[0].message}`)}}const Ge=()=>{const[l,i]=x.useState("idle"),[a,c]=x.useState([]),[n,m]=x.useState(null),[e,p]=x.useState(null),[k,d]=x.useState(""),[j,v]=x.useState({allowed:!0,remaining:5}),[g,C]=x.useState(null),[Y,y]=x.useState(null),[o,oe]=x.useState(!1),[U,N]=x.useState(null),[F,E]=x.useState(null),[P,I]=x.useState("page"),[T,M]=x.useState(null),[J,He]=x.useState("all"),[S,W]=x.useState(""),[L,ae]=x.useState("general");x.useEffect(()=>{se(),ne()},[]),x.useEffect(()=>{if(e){const r=window.matchMedia("(prefers-color-scheme: dark)").matches,s=e.theme==="dark"||e.theme==="system"&&r;oe(s),document.body.classList.toggle("dark",s)}},[e]);async function ne(){const r=await chrome.storage.local.get(["ate_extract_mode","ate_selected_text"]);r.ate_extract_mode==="selection"&&r.ate_selected_text&&(I("selection"),M(r.ate_selected_text),await chrome.storage.local.remove(["ate_extract_mode","ate_selected_text"]))}async function se(){const[r,s]=await Promise.all([ye(),X()]);p(r),v(s);try{const[u]=await chrome.tabs.query({active:!0,currentWindow:!0});u.title&&u.url&&C({title:u.title,url:u.url})}catch{}}async function z(){if(!e)return;const s={...e,theme:o?"light":"dark"};p(s),await fe(s)}async function le(){if(!e)return;if(!j.allowed){d("Daily limit reached. Upgrade to Pro for unlimited extractions."),i("error");return}if(!(e.aiProvider==="openai"?e.openaiApiKey:e.anthropicApiKey)){d(`Please configure your ${e.aiProvider==="openai"?"OpenAI":"Anthropic"} API key in settings.`),i("error");return}i("extracting"),d("");try{let s,u,h;const[b]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!b.id)throw new Error("No active tab");if(P==="selection"&&T)s=T,u=b.title||"Selected Text",h=b.url||"";else{const w=await chrome.tabs.sendMessage(b.id,{type:"GET_PAGE_CONTENT"});if(!(w!=null&&w.content))throw new Error("Could not extract page content. Try refreshing the page.");s=w.content,u=w.title,h=w.url}const A=await qe(s,u,e,L);if(A.length===0){d("No tasks found. Try a different page or selection with action items or meeting notes."),i("error");return}a.length>0&&m([...a]),c(A),C({title:u,url:h}),await be();const ge=await X();v(ge);const Q={id:R(),sourceUrl:h,sourceTitle:u,tasks:A,extractedAt:Date.now()};await we(Q),await ke({id:Q.id,sourceUrl:h,sourceTitle:u,taskCount:A.length,extractedAt:Date.now()}),I("page"),M(null),i("results")}catch(s){d(s instanceof Error?s.message:"Extraction failed"),i("error")}}function ce(){n&&(c(n),m(null))}function $(r,s,u){m([...a]),c(h=>h.map(b=>b.id===r?{...b,[s]:u}:b)),N(null),E(null)}function de(r,s){m([...a]),c(u=>u.map(h=>h.id===r?{...h,priority:s}:h))}function ue(r){m([...a]),c(s=>s.filter(u=>u.id!==r))}function K(r){c(r==="all"?s=>s.map(u=>({...u,selected:!0})):s=>s.map(u=>({...u,selected:u.category===r})))}function O(r){c(s=>s.map(u=>({...u,selected:u.priority===r})))}const V=a.filter(r=>{var s,u;if(J!=="all"&&r.category!==J)return!1;if(S){const h=S.toLowerCase();return r.title.toLowerCase().includes(h)||((s=r.description)==null?void 0:s.toLowerCase().includes(h))||((u=r.assignee)==null?void 0:u.toLowerCase().includes(h))}return!0});function me(r){c(s=>s.map(u=>u.id===r?{...u,selected:!u.selected}:u))}function pe(){c(r=>r.map(s=>({...s,selected:!0})))}function xe(){c(r=>r.map(s=>({...s,selected:!1})))}async function f(r){if(!e||!g)return;const s=a.filter(u=>u.selected);if(s.length===0){d("Please select at least one task to export");return}i("exporting");try{switch(r){case"clipboard":await te(Be(a)),y("Copied to clipboard!");break;case"markdown":await te(Ye(a,g.title)),y("Markdown copied to clipboard!");break;case"csv":if(!e.isPro){d("CSV export is a Pro feature. Upgrade to unlock."),i("error");return}re(We(a,g.title),`tasks-${new Date().toISOString().split("T")[0]}.csv`,"text/csv"),y("CSV downloaded!");break;case"json":if(!e.isPro){d("JSON export is a Pro feature. Upgrade to unlock."),i("error");return}re(ze(a,g.title),`tasks-${new Date().toISOString().split("T")[0]}.json`,"application/json"),y("JSON downloaded!");break;case"notion":if(!e.isPro){d("Notion export is a Pro feature. Upgrade to unlock."),i("error");return}await Ue(a,e,g.title),y(`Exported ${s.length} tasks to Notion!`);break;case"todoist":if(!e.isPro){d("Todoist export is a Pro feature. Upgrade to unlock."),i("error");return}await Fe(a,e),y(`Exported ${s.length} tasks to Todoist!`);break;case"clickup":if(!e.isPro){d("ClickUp export is a Pro feature. Upgrade to unlock."),i("error");return}await Je(a,e),y(`Exported ${s.length} tasks to ClickUp!`);break;case"asana":if(!e.isPro){d("Asana export is a Pro feature. Upgrade to unlock."),i("error");return}await Ke(a,e),y(`Exported ${s.length} tasks to Asana!`);break;case"linear":if(!e.isPro){d("Linear export is a Pro feature. Upgrade to unlock."),i("error");return}await Ve(a,e),y(`Exported ${s.length} tasks to Linear!`);break}i("results"),setTimeout(()=>y(null),3e3)}catch(u){d(u instanceof Error?u.message:"Export failed"),i("error")}}function G(){chrome.runtime.openOptionsPage()}function H(){i("idle"),c([]),d(""),y(null)}const he=a.filter(r=>r.selected).length;return l==="idle"?t.jsxs("div",{className:`w-[400px] p-4 ${o?"bg-gray-900":"bg-white"}`,children:[t.jsxs("div",{className:"flex items-center justify-between mb-4",children:[t.jsx("h1",{className:`text-lg font-bold ${o?"text-gray-100":"text-gray-900"}`,children:"AI Task Extractor"}),t.jsxs("div",{className:"flex items-center gap-2",children:[t.jsx("button",{onClick:z,className:`p-1.5 rounded-lg transition-colors ${o?"bg-gray-700 text-yellow-400 hover:bg-gray-600":"bg-gray-100 text-gray-600 hover:bg-gray-200"}`,title:o?"Light mode":"Dark mode",children:o?t.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"})}):t.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"})})}),t.jsx("button",{onClick:G,className:`p-1.5 rounded-lg transition-colors ${o?"text-gray-400 hover:text-gray-200 hover:bg-gray-700":"text-gray-500 hover:text-gray-700 hover:bg-gray-100"}`,title:"Settings",children:t.jsxs("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:[t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"}),t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M15 12a3 3 0 11-6 0 3 3 0 016 0z"})]})})]})]}),g&&t.jsxs("div",{className:`mb-4 p-3 rounded-lg ${o?"bg-gray-800":"bg-gray-50"}`,children:[t.jsx("p",{className:`text-xs mb-1 ${o?"text-gray-400":"text-gray-500"}`,children:"Current page:"}),t.jsx("p",{className:`text-sm font-medium truncate ${o?"text-gray-200":"text-gray-700"}`,children:g.title})]}),P==="selection"&&T&&t.jsxs("div",{className:`mb-4 p-3 rounded-lg border-2 border-dashed ${o?"bg-primary-900/20 border-primary-700":"bg-primary-50 border-primary-200"}`,children:[t.jsxs("div",{className:"flex items-center gap-2 mb-2",children:[t.jsx("svg",{className:`w-4 h-4 ${o?"text-primary-400":"text-primary-600"}`,fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"})}),t.jsx("span",{className:`text-xs font-medium ${o?"text-primary-300":"text-primary-700"}`,children:"Extracting from selection"})]}),t.jsxs("p",{className:`text-xs truncate ${o?"text-gray-400":"text-gray-600"}`,children:['"',T.substring(0,100),T.length>100?"...":"",'"']}),t.jsx("button",{onClick:()=>{I("page"),M(null)},className:`mt-2 text-xs ${o?"text-primary-400 hover:text-primary-300":"text-primary-600 hover:text-primary-700"}`,children:"Use full page instead"})]}),t.jsxs("div",{className:"text-center py-6",children:[t.jsx("div",{className:`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${o?"bg-primary-900/30":"bg-primary-100"}`,children:t.jsx("svg",{className:"w-8 h-8 text-primary-500",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"})})}),t.jsx("h2",{className:`text-lg font-semibold mb-2 ${o?"text-gray-100":"text-gray-900"}`,children:P==="selection"?"Extract Tasks from Selection":"Extract Tasks from This Page"}),t.jsxs("p",{className:`text-sm mb-4 ${o?"text-gray-400":"text-gray-600"}`,children:["AI will analyze the ",P==="selection"?"selected text":"page content"," and identify actionable tasks, deadlines, and follow-ups."]}),t.jsxs("div",{className:"mb-4",children:[t.jsx("label",{className:"block text-xs mb-2 text-gray-500",children:"Extraction Mode:"}),t.jsx("div",{className:"flex gap-2 justify-center",children:["general","email","meeting"].map(r=>{const s=r!=="general"&&!(e!=null&&e.isPro);return t.jsxs("button",{onClick:()=>!s&&ae(r),disabled:s,className:`px-3 py-1.5 text-xs rounded-lg border transition-colors ${L===r?o?"border-primary-500 bg-primary-900/30 text-primary-400":"border-primary-500 bg-primary-50 text-primary-700":s?o?"border-gray-700 bg-gray-800 text-gray-600 cursor-not-allowed":"border-gray-200 bg-gray-50 text-gray-400 cursor-not-allowed":o?"border-gray-600 bg-gray-800 text-gray-300 hover:border-gray-500":"border-gray-300 bg-white text-gray-700 hover:border-gray-400"}`,title:s?"Pro feature":ee[r],children:[r==="email"&&"📧 ",r==="meeting"&&"📅 ",r==="general"&&"📄 ",Ee[r],s&&" 🔒"]},r)})}),t.jsx("p",{className:`text-xs mt-1 ${o?"text-gray-500":"text-gray-400"}`,children:ee[L]})]}),t.jsx("button",{onClick:le,className:"btn-primary w-full",children:"Extract Tasks"})]}),!(e!=null&&e.isPro)&&t.jsxs("div",{className:"mt-3 text-center text-sm text-gray-500",children:[j.remaining," of 5 free extractions remaining today"]})]}):l==="extracting"?t.jsx("div",{className:`w-[400px] p-4 ${o?"bg-gray-900":"bg-white"}`,children:t.jsxs("div",{className:"flex flex-col items-center justify-center py-12",children:[t.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mb-4"}),t.jsxs("p",{className:o?"text-gray-300":"text-gray-600",children:["Analyzing ",P==="selection"?"selection":"page content","..."]}),t.jsx("p",{className:`text-sm mt-2 ${o?"text-gray-500":"text-gray-400"}`,children:"Identifying tasks and action items"})]})}):l==="exporting"?t.jsx("div",{className:`w-[400px] p-4 ${o?"bg-gray-900":"bg-white"}`,children:t.jsxs("div",{className:"flex flex-col items-center justify-center py-12",children:[t.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mb-4"}),t.jsx("p",{className:o?"text-gray-300":"text-gray-600",children:"Exporting tasks..."})]})}):l==="error"?t.jsx("div",{className:`w-[400px] p-4 ${o?"bg-gray-900":"bg-white"}`,children:t.jsxs("div",{className:"text-center py-8",children:[t.jsx("div",{className:`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 ${o?"bg-red-900/30":"bg-red-100"}`,children:t.jsx("svg",{className:"w-6 h-6 text-red-500",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})}),t.jsx("h2",{className:`text-lg font-semibold mb-2 ${o?"text-gray-100":"text-gray-900"}`,children:"Error"}),t.jsx("p",{className:`mb-6 ${o?"text-gray-400":"text-gray-600"}`,children:k}),t.jsxs("div",{className:"flex gap-2 justify-center",children:[t.jsx("button",{onClick:H,className:"btn-secondary",children:"Try Again"}),t.jsx("button",{onClick:G,className:"btn-outline",children:"Settings"})]})]})}):l==="results"?t.jsxs("div",{className:`w-[400px] max-h-[500px] flex flex-col ${o?"bg-gray-900":"bg-white"}`,children:[t.jsxs("div",{className:`p-4 border-b ${o?"border-gray-700":"border-gray-200"}`,children:[t.jsxs("div",{className:"flex items-center justify-between mb-2",children:[t.jsxs("h1",{className:`text-lg font-bold ${o?"text-gray-100":"text-gray-900"}`,children:[a.length," Task",a.length!==1?"s":""," Found"]}),t.jsxs("div",{className:"flex items-center gap-2",children:[n&&t.jsx("button",{onClick:ce,className:`p-1.5 rounded-lg transition-colors ${o?"text-gray-400 hover:text-gray-200 hover:bg-gray-700":"text-gray-500 hover:text-gray-700 hover:bg-gray-100"}`,title:"Undo",children:t.jsx("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"})})}),t.jsx("button",{onClick:z,className:`p-1.5 rounded-lg transition-colors ${o?"text-yellow-400 hover:bg-gray-700":"text-gray-500 hover:bg-gray-100"}`,title:o?"Light mode":"Dark mode",children:o?t.jsx("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"})}):t.jsx("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"})})}),t.jsx("button",{onClick:H,className:`text-sm ${o?"text-gray-400 hover:text-gray-200":"text-gray-500 hover:text-gray-700"}`,children:"← Back"})]})]}),g&&t.jsx("p",{className:`text-sm truncate ${o?"text-gray-400":"text-gray-500"}`,children:g.title}),Y&&t.jsx("div",{className:`mt-2 p-2 text-sm rounded-lg ${o?"bg-green-900/30 text-green-400":"bg-green-50 text-green-700"}`,children:Y})]}),t.jsxs("div",{className:"flex-1 overflow-y-auto p-4",children:[t.jsxs("div",{className:"flex items-center justify-between mb-3",children:[t.jsxs("span",{className:`text-sm ${o?"text-gray-400":"text-gray-500"}`,children:[he," of ",V.length," selected"]}),t.jsxs("div",{className:"flex gap-2",children:[t.jsx("button",{onClick:pe,className:"text-xs text-primary-500 hover:underline",children:"Select all"}),t.jsx("button",{onClick:xe,className:`text-xs hover:underline ${o?"text-gray-400":"text-gray-500"}`,children:"Deselect all"})]})]}),(e==null?void 0:e.isPro)&&t.jsx("div",{className:"mb-3",children:t.jsxs("div",{className:"relative",children:[t.jsx("svg",{className:`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${o?"text-gray-500":"text-gray-400"}`,fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"})}),t.jsx("input",{type:"text",value:S,onChange:r=>W(r.target.value),placeholder:"Search tasks...",className:`w-full pl-9 pr-3 py-1.5 text-sm rounded-lg border ${o?"bg-gray-800 border-gray-600 text-gray-100 placeholder-gray-500":"bg-white border-gray-300 text-gray-900 placeholder-gray-400"} focus:outline-none focus:ring-2 focus:ring-primary-500`}),S&&t.jsx("button",{onClick:()=>W(""),className:`absolute right-3 top-1/2 -translate-y-1/2 ${o?"text-gray-500 hover:text-gray-300":"text-gray-400 hover:text-gray-600"}`,children:t.jsx("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})})]})}),t.jsxs("div",{className:`flex flex-wrap gap-1 mb-3 pb-3 border-b ${o?"border-gray-700":"border-gray-200"}`,children:[t.jsx("span",{className:`text-xs mr-1 ${o?"text-gray-500":"text-gray-400"}`,children:"Select:"}),t.jsx("button",{onClick:()=>O("high"),className:`text-xs px-2 py-0.5 rounded ${o?"bg-red-900/30 text-red-400 hover:bg-red-900/50":"bg-red-100 text-red-700 hover:bg-red-200"}`,children:"High"}),t.jsx("button",{onClick:()=>O("medium"),className:`text-xs px-2 py-0.5 rounded ${o?"bg-amber-900/30 text-amber-400 hover:bg-amber-900/50":"bg-amber-100 text-amber-700 hover:bg-amber-200"}`,children:"Medium"}),t.jsx("button",{onClick:()=>O("low"),className:`text-xs px-2 py-0.5 rounded ${o?"bg-green-900/30 text-green-400 hover:bg-green-900/50":"bg-green-100 text-green-700 hover:bg-green-200"}`,children:"Low"}),t.jsx("span",{className:`text-xs mx-1 ${o?"text-gray-600":"text-gray-300"}`,children:"|"}),t.jsx("button",{onClick:()=>K("action"),className:`text-xs px-2 py-0.5 rounded ${o?"bg-gray-700 text-gray-300 hover:bg-gray-600":"bg-gray-100 text-gray-600 hover:bg-gray-200"}`,children:"Actions"}),t.jsx("button",{onClick:()=>K("follow-up"),className:`text-xs px-2 py-0.5 rounded ${o?"bg-gray-700 text-gray-300 hover:bg-gray-600":"bg-gray-100 text-gray-600 hover:bg-gray-200"}`,children:"Follow-ups"})]}),t.jsx("div",{className:"space-y-2",children:V.map(r=>t.jsx("div",{className:`p-3 rounded-lg border transition-colors ${r.selected?o?"border-primary-700 bg-primary-900/20":"border-primary-200 bg-primary-50":o?"border-gray-700 bg-gray-800":"border-gray-200 bg-white"}`,children:t.jsxs("div",{className:"flex items-start gap-3",children:[t.jsx("input",{type:"checkbox",checked:r.selected,onChange:()=>me(r.id),className:"checkbox mt-0.5"}),t.jsxs("div",{className:"flex-1 min-w-0",children:[t.jsxs("div",{className:"flex items-center gap-2 mb-1",children:[t.jsx("span",{className:"text-lg",title:D[r.category],children:ie[r.category]}),t.jsxs("select",{value:r.priority,onChange:s=>de(r.id,s.target.value),className:"text-xs rounded px-1.5 py-0.5 border-0 cursor-pointer",style:{backgroundColor:`${Z[r.priority]}20`,color:Z[r.priority]},children:[t.jsx("option",{value:"high",children:"High"}),t.jsx("option",{value:"medium",children:"Medium"}),t.jsx("option",{value:"low",children:"Low"})]}),t.jsx("button",{onClick:()=>ue(r.id),className:`ml-auto p-1 rounded opacity-50 hover:opacity-100 transition-opacity ${o?"hover:bg-gray-700 text-gray-400":"hover:bg-gray-100 text-gray-400"}`,title:"Delete task",children:t.jsx("svg",{className:"w-3.5 h-3.5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})})]}),U===r.id&&F==="title"?t.jsx("input",{type:"text",defaultValue:r.title,autoFocus:!0,className:`task-edit-input font-medium ${o?"text-gray-100":"text-gray-900"}`,onBlur:s=>$(r.id,"title",s.target.value),onKeyDown:s=>{s.key==="Enter"?$(r.id,"title",s.target.value):s.key==="Escape"&&(N(null),E(null))}}):t.jsx("p",{className:`font-medium cursor-pointer hover:underline ${o?"text-gray-100":"text-gray-900"}`,onClick:()=>{N(r.id),E("title")},title:"Click to edit",children:r.title}),r.description&&(U===r.id&&F==="description"?t.jsx("input",{type:"text",defaultValue:r.description,autoFocus:!0,className:`task-edit-input text-sm mt-1 ${o?"text-gray-300":"text-gray-600"}`,onBlur:s=>$(r.id,"description",s.target.value),onKeyDown:s=>{s.key==="Enter"?$(r.id,"description",s.target.value):s.key==="Escape"&&(N(null),E(null))}}):t.jsx("p",{className:`text-sm mt-1 cursor-pointer hover:underline ${o?"text-gray-400":"text-gray-600"}`,onClick:()=>{N(r.id),E("description")},title:"Click to edit",children:r.description})),t.jsxs("div",{className:"flex flex-wrap items-center gap-2 mt-2 text-xs text-gray-500",children:[r.assignee&&t.jsxs("span",{children:["👤 ",r.assignee]}),r.dueDate&&t.jsxs("span",{children:["📅 ",r.dueDate]}),(e==null?void 0:e.isPro)&&(e==null?void 0:e.showTimeEstimates)&&r.timeEstimate&&t.jsxs("span",{className:`px-1.5 py-0.5 rounded ${o?"bg-blue-900/30 text-blue-400":"bg-blue-100 text-blue-700"}`,title:"Estimated time",children:["⏱️ ",Te[r.timeEstimate]]}),(e==null?void 0:e.isPro)&&(e==null?void 0:e.showRecurring)&&r.recurring&&t.jsxs("span",{className:`px-1.5 py-0.5 rounded ${o?"bg-purple-900/30 text-purple-400":"bg-purple-100 text-purple-700"}`,title:r.recurring.description,children:["🔄 ",Pe[r.recurring.frequency]]}),r.sender&&t.jsxs("span",{children:["✉️ ",r.sender]}),r.attendees&&r.attendees.length>0&&t.jsxs("span",{title:r.attendees.join(", "),children:["👥 ",r.attendees.length]}),(e==null?void 0:e.isPro)&&e.showConfidence&&r.confidence!==void 0&&t.jsxs("span",{className:`px-1.5 py-0.5 rounded text-xs ${r.confidence>=.8?o?"bg-green-900/30 text-green-400":"bg-green-100 text-green-700":r.confidence>=.5?o?"bg-amber-900/30 text-amber-400":"bg-amber-100 text-amber-700":o?"bg-red-900/30 text-red-400":"bg-red-100 text-red-700"}`,title:"AI confidence score",children:[Math.round(r.confidence*100),"%"]})]}),(e==null?void 0:e.isPro)&&r.subTasks&&r.subTasks.length>0&&t.jsxs("div",{className:`mt-2 pl-4 border-l-2 ${o?"border-gray-700":"border-gray-200"}`,children:[t.jsxs("p",{className:`text-xs mb-1 ${o?"text-gray-500":"text-gray-400"}`,children:["Sub-tasks (",r.subTasks.length,"):"]}),t.jsxs("ul",{className:"space-y-0.5",children:[r.subTasks.slice(0,3).map(s=>t.jsxs("li",{className:`text-xs flex items-center gap-1 ${o?"text-gray-400":"text-gray-600"}`,children:[t.jsx("span",{className:`w-1.5 h-1.5 rounded-full ${o?"bg-gray-600":"bg-gray-300"}`}),s.title]},s.id)),r.subTasks.length>3&&t.jsxs("li",{className:`text-xs ${o?"text-gray-500":"text-gray-400"}`,children:["+",r.subTasks.length-3," more..."]})]})]})]})]})},r.id))})]}),t.jsxs("div",{className:`p-4 border-t ${o?"border-gray-700 bg-gray-800":"border-gray-200 bg-gray-50"}`,children:[t.jsx("p",{className:"text-xs mb-2 text-gray-500",children:"Export selected tasks:"}),t.jsxs("div",{className:"grid grid-cols-2 gap-2 mb-2",children:[t.jsx("button",{onClick:()=>f("clipboard"),className:"btn-secondary text-sm py-2",children:"📋 Copy"}),t.jsx("button",{onClick:()=>f("markdown"),className:"btn-secondary text-sm py-2",children:"📝 Markdown"})]}),t.jsxs("div",{className:"grid grid-cols-3 gap-1.5",children:[t.jsxs("button",{onClick:()=>f("csv"),disabled:!(e!=null&&e.isPro),className:"btn-outline text-xs py-1.5 disabled:opacity-50",title:e!=null&&e.isPro?"":"Pro feature",children:["CSV ",!(e!=null&&e.isPro)&&"🔒"]}),t.jsxs("button",{onClick:()=>f("json"),disabled:!(e!=null&&e.isPro),className:"btn-outline text-xs py-1.5 disabled:opacity-50",title:e!=null&&e.isPro?"":"Pro feature",children:["JSON ",!(e!=null&&e.isPro)&&"🔒"]}),t.jsxs("button",{onClick:()=>f("notion"),disabled:!(e!=null&&e.isPro),className:"btn-outline text-xs py-1.5 disabled:opacity-50",title:e!=null&&e.isPro?"":"Pro feature",children:["Notion ",!(e!=null&&e.isPro)&&"🔒"]}),t.jsxs("button",{onClick:()=>f("todoist"),disabled:!(e!=null&&e.isPro),className:"btn-outline text-xs py-1.5 disabled:opacity-50",title:e!=null&&e.isPro?"":"Pro feature",children:["Todoist ",!(e!=null&&e.isPro)&&"🔒"]}),t.jsxs("button",{onClick:()=>f("clickup"),disabled:!(e!=null&&e.isPro),className:"btn-outline text-xs py-1.5 disabled:opacity-50",title:e!=null&&e.isPro?"":"Pro feature",children:["ClickUp ",!(e!=null&&e.isPro)&&"🔒"]}),t.jsxs("button",{onClick:()=>f("asana"),disabled:!(e!=null&&e.isPro),className:"btn-outline text-xs py-1.5 disabled:opacity-50",title:e!=null&&e.isPro?"":"Pro feature",children:["Asana ",!(e!=null&&e.isPro)&&"🔒"]}),t.jsxs("button",{onClick:()=>f("linear"),disabled:!(e!=null&&e.isPro),className:"btn-outline text-xs py-1.5 disabled:opacity-50 col-span-3",title:e!=null&&e.isPro?"":"Pro feature",children:["Linear ",!(e!=null&&e.isPro)&&"🔒"]})]})]})]}):null};je.createRoot(document.getElementById("root")).render(t.jsx(ve.StrictMode,{children:t.jsx(Ge,{})}));
